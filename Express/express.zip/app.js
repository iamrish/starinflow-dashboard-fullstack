// 100% node.js under the hood
// The routers do add like a piece of middleware! interesting
const express = require("express");
const getCaseDataRunner = require("./getCaseData");
const getEntropyDataRunner = require("./getEntropyData");

const app = express();
const caseRouter = express.Router();
const entropyRouter = express.Router();

// 1. MIDDLEWARE
app.use(express.json());
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  // res.header(
  //   "Access-Control-Allow-Headers",
  //   "Origin, X-Requested-With, Content-Type, Accept"
  // );
  next();
});

app.use("/api/v1/cases", caseRouter);
app.use("/api/v1/entropy", entropyRouter);

// 2. API request handler
const apiController = (router, data) => {
  router.route("/:country").get((req, res) => {
    let flag = 0;
    for (obj of data) {
      if (req.params.country === obj.country) {
        flag = 1;
        break;
      }
    }
    if (!flag) {
      res.status(404).json({
        status: "failiure",
        message: "Invalid country",
      });
    } else {
      res.status(200).json({
        status: "success",
        data: obj,
      });
    }
  });
};
const caseRunner = async () => {
  const data = await getCaseDataRunner(`${__dirname}/data/cases`);
  apiController(caseRouter, data);
};

const entropyRunner = async () => {
  const data = await getEntropyDataRunner(`${__dirname}/data/entropy`);
  apiController(entropyRouter, data);
};

caseRunner().then(() => {
  entropyRunner();
});
module.exports = app;
