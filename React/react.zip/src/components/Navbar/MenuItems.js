const MenuItems = [
  {
    title: "Cases Plots",
    to: "/",
    cName: "nav-link",
  },
  {
    title: "Entropy Plots",
    to: "/entropy-plots",
    cName: "nav-link",
  },
  {
    title: "Paper",
    to: "/paper",
    cName: "nav-link",
  },
];

export default MenuItems;
